<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Illuminate\Http\Response;
use Illuminate\Contracts\Filesystem\Factory;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class TicketsController extends Controller
{

    public function __construct()
    {
        
    }

    function priority(Request $request, $items = null, $number = null) {
      $read = json_decode(Storage::get('tickets.json'), true);
      $data = $this->definePriorities( $read );
      $data = $this->pagination( $data, $items, $number);
      return $data;
    }

    function definePriorities( $read ) {
      $data = array();
      foreach ($read as $value) {
        $ticketID = $value['TicketID'];
        $punctuation = $this->verifyTimeResolution( $value['DateCreate'], $value['DateUpdate'] );
        foreach ($value['Interactions'] as $msg) {
          $punctuation = $punctuation + $this->verifyWords( $msg['Message'] ) + $this->verifySubject( $msg['Subject'] );
        }
        $value = array( 'Priority' => $this->isPriorityHigh( $punctuation ), 'Punctuation' => $punctuation ) + $value;
        array_push($data,$value);
      }

      return $data;
    }

    function verifyTimeResolution( $create, $update ){
      $dateCreate = explode(" ", $create);
      $dateUpdate = explode(" ", $update);

      $create = new \DateTime( $dateCreate[0] );
      $update = new \DateTime( $dateUpdate[0] );

      $interval = $create->diff( $update );
      $interval = ( $interval->m * 30 ) + ( $interval->d );
      return ( $interval > 45 ? 1 : 0 ) ;
    }

    function verifyWords( $message ) {
      $badWords = array('Não',
                         'não', 
                         'nao foi entregue', 
                         'não foi entregue', 
                         'providências', 
                         'providencias', 
                         'não consigo',
                         'nao consigo',
                         'cancelamento',
                         'não chegou',
                         'nao chegou',
                         'não funciona',
                         'nao funciona');
      $countWords = 0;
      foreach ($badWords as $words) {
        $countWords = $countWords + substr_count($message, $words);
      }
      return $countWords;
    }

    function verifySubject( $subject ) {
      return $subject === 'Reclamação' ? 4 : 0;
    }

    function isPriorityHigh( $count ) {
      if ( $count >= 4 )
        return 'Prioridade Alta';
      return 'Prioridade Baixa';
    }

    function pagination( $read, $items, $number ) {
      $page = $number;
      $total = count( $read ); // # Total items in array    
      $limit = $items; // # Per page    
      $totalPages = ceil( $total/ $limit ); // # Calculate total pages
      $page = max($page, 1); // # Get 1 page when page <= 0
      $page = min($page, $totalPages); // # Get last page when page > $totalPages
      $offset = ($page - 1) * $limit;
      if( $offset < 0 ) $offset = 0;
      $read = array_slice( $read, $offset, $limit );
      $read = array('Number' => $page, 'Pages' => $totalPages, 'Items' => $total) + $read;
      return $read;
    }
}


